package mk.ukim.finki.wp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebProgrammingLabApplicationTests {

    @Test
    void contextLoads() {
    }

}
